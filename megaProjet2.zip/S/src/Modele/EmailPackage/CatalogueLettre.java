//In this package
package Modele.EmailPackage;

import java.io.IOException;
import java.io.PrintWriter;

import Modele.ClientPackage.Employ�;

//Import what this class use
public class CatalogueLettre
{	
	private Email newsletter = null;
	private Employ� customerH = null;
	
	/**
	 * Constructor
	 */
	public CatalogueLettre(Employ� ch)
	{
		super();
		this.newsletter = new Email();
		this.customerH = ch;
	}
	
	/**
	 * Constructor
	 * @param title		Title of newsletter
	 * @param content	Content of newsletter
	 */
	public CatalogueLettre(String title, String content)
	{
		super();
		this.newsletter = new Email(title, content);
	}
	
	/**
	 * Get newsletter
	 * @return			Email
	 */
	public Email getEmail()
	{
		return this.newsletter;
	}
	
	/**
	 * Set title of newsletter
	 * @param title		Title of newsletter
	 */
	public void setTitle(String title)
	{
		this.newsletter.setTitle(title);
	}
	
	/**
	 * Set content of newsletter
	 * @param content	Content of newsletter
	 */
	public void setContent(String content)
	{
		this.newsletter.setContent(content);
	}
	
	/**
	 * Get addresslist of customers
	 * @param preference	Preference of customers
	 */
	public void getAddressList(String preference)
	{
		this.newsletter.setAddressList(this.customerH.getCustomersWithPreferences(preference));
	}
	
	/**
	 * Send newsletter
	 */
	public void send()
	{
		int size = this.newsletter.getAddressList().size();
		
		try
		{
			for(int i = 0; i < size; i++)
			{
				String temp = this.newsletter.getAddressList().elementAt(i);
				PrintWriter out = new PrintWriter(this.newsletter.getTitle() + "#" + i + ".txt");
				
				out.println(temp + "\r\n");
				out.println(this.newsletter.getTitle() + "\r\n");
				out.println(this.newsletter.getContent());
				
				out.close();
			}
		}
		catch (IOException e)
		{
			e.printStackTrace();
		}
	}
}
