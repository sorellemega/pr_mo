//In this package
package Vue;

import Modele.ClientPackage.*;
import Modele.EmailPackage.*;
import Modele.ArticlePackage.*;
import Modele.LigneArticle;
import Modele.Location;
import Modele.ArticlePackage.DescriptionProduit;
import Modele.ClientPackage.Employ�;
import Modele.EmailPackage.CatalogueLettre;
import Controleur.ClubVideo;

import java.awt.Container;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import java.awt.Color;
import java.awt.Toolkit;

public class InterfaceSysteme extends JFrame
{
	
    /**
     * 
     */
    private static final long serialVersionUID = 1L;
    private Container contentPane;
   
    //GUIs
    private InterfaceClient guiCustomer;
    private InterfaceArticle guiItem;
    private InterfaceEmail guiNewsLetter;
    private InterfacePret guiRental;
    private InterfaceRecherche guiSearch;
    
    private ClubVideo MainSystemReference;
    
    public InterfaceSysteme(ClubVideo MainSystem)
	{
    	super();
    	setIconImage(Toolkit.getDefaultToolkit().getImage("C:\\Users\\sorelle\\Pictures\\insta_square\\s.png"));
    	this.MainSystemReference = MainSystem;
		initiateInstanceVariables();
		configureFrame();
		buildPanel();
		this.setVisible(true);
	}
    
    public class ButtonListener implements ActionListener
	{

		public void actionPerformed(ActionEvent e) // Executes when button pressed
		{
			String buttonText = e.getActionCommand();
			
			if(buttonText.equals("New rental"))
			{
				enterRental();
			}
			else if(buttonText.equals("Customers"))
			{
				enterCustumers();
			}
			else if(buttonText.equals("Items"))
			{
				enterItems();
			}
			else if(buttonText.equals("Search"))
			{
				enterSearch();
			}
			else if(buttonText.equals("Write newsletter"))
			{
				enterEmail();
			}
			else if(buttonText.equals("Logout"))
			{
				logout();
			}
		}

	}
    	private void logout() 
	{
    	    JOptionPane.showMessageDialog(null, "Exit the system");
    	    //Save
    	    try {
				this.MainSystemReference.save();
			} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
    	    System.exit(0);
	}

	private void enterEmail() 
	{
		CatalogueLettre EmailH = this.MainSystemReference.getCatalogueLettre();
		this.guiNewsLetter = new InterfaceEmail(EmailH);
	    guiNewsLetter.setVisible(true);
	    
	}

	private void enterSearch() 
	{
		LigneArticle SearchH = this.MainSystemReference.getSerchHandler();
		this.guiSearch = new InterfaceRecherche(SearchH);
		guiSearch.setVisible(true);
	    
	}

	private void enterItems() 
	{
		DescriptionProduit ItemH = this.MainSystemReference.getDescriptionProduit();
		this.guiItem = new InterfaceArticle(ItemH);
	    guiItem.setVisible(true);
	    
	}

	private void enterCustumers() 
	{
		Employ� customerH = this.MainSystemReference.getEmploy�();
		this.guiCustomer = new InterfaceClient(customerH);
	    guiCustomer.setVisible(true);
	    
	}

	private void enterRental() 
	{
		Location RentalH = this.MainSystemReference.getLocation();
		this.guiRental = new InterfacePret(RentalH);
	    guiRental.setVisible(true);
	}
	
	
	private void initiateInstanceVariables()
	{
		this.contentPane = this.getContentPane();
		this.contentPane.setLayout(new GridLayout(1, 2));
	}
	
	private void configureFrame()
	{
		this.setSize(400, 400);
		this.setTitle("Club Video");
		this.setLocationRelativeTo(null);
		
		this.setDefaultCloseOperation(DO_NOTHING_ON_CLOSE);
	}
	
	private void buildPanel()
	{
		JPanel panel = new JPanel();
		panel.setBackground(new Color(255, 222, 173));
		panel.setBorder(BorderFactory.createTitledBorder("Syst�me de pr�t"));
		
		buildButtonPanel(panel);
		
		this.contentPane.add(panel);
	}
	
	private void buildButtonPanel(JPanel thePanel)
	{
		JPanel buttonPanel = new JPanel();
		buttonPanel.setLayout(new BoxLayout(buttonPanel, BoxLayout.Y_AXIS));
		
		String[] buttonTxt = {"New rental", "Customers", "Items", "Search", "Write newsletter", "Logout"};
		ButtonListener buttonListener = new ButtonListener();
		
		JButton button = new JButton(buttonTxt[0]);
		Dimension dim = button.getPreferredSize();
		buttonPanel.setSize(50*dim.width + 8, 2 * dim.height + 5);
		buttonPanel.setLocation(20,70);
		
		// Add all buttons to button panel
		for(String str: buttonTxt)
		{
			button = new JButton(str);
			buttonPanel.add(button);
			// connect listener
			button.addActionListener(buttonListener);
		}
		
		thePanel.add(buttonPanel);
		this.contentPane.add(thePanel);
	}
}
