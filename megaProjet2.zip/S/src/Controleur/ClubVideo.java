//Import all models
package Controleur;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

import Modele.*;
import Modele.ClientPackage.*;
import Modele.ArticlePackage.*;
import Modele.EmailPackage.*;
import Modele.Catalogue;
import Modele.LigneArticle;
import Modele.Location;
import Modele.ArticlePackage.DescriptionProduit;
import Modele.ClientPackage.Employ�;
import Modele.EmailPackage.CatalogueLettre;
import Vue.*;
import java.awt.Color;
import java.awt.BorderLayout;
import java.awt.CardLayout;
import java.awt.GridBagLayout;
import com.jgoodies.forms.layout.FormLayout;
import com.jgoodies.forms.layout.ColumnSpec;
import com.jgoodies.forms.layout.RowSpec;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import java.awt.FlowLayout;
import javax.swing.BoxLayout;
import java.awt.GridLayout;
import java.awt.SystemColor;
import java.awt.Window.Type;
import javax.swing.UIManager;

public class ClubVideo
{
	private Employ� 	CustomerH;
	private DescriptionProduit 		ItemH;
	private CatalogueLettre 	EmailH;
	private Location 		RentalH;
	private	LigneArticle 		SearchH;
	private Catalogue 			database;
	private InterfaceSysteme			SystemGui;
	

	
	//Construct
	public ClubVideo()
	{
		//Handlers and Catalogue
		this.CustomerH 		= new Employ�();
		this.ItemH 			= new DescriptionProduit();
		this.RentalH 		= new Location();
		
		//Load
		this.loadResult();
		
		this.EmailH	= new CatalogueLettre(this.CustomerH);
		this.SearchH 		= new LigneArticle(this.ItemH, this.CustomerH);
		this.RentalH.setHandlers(this.ItemH, this.CustomerH);
		this.database 		= new Catalogue();
		this.SystemGui		= new InterfaceSysteme(this);
		//---------------------------------------
		
		
	}
	
	/**
	 * Get Employ�
	 * @return		Employ�
	 */
	public Employ� getEmploy�()
	{
		return this.CustomerH;
	}
	
	/**
	 * Get DescriptionProduit
	 * @return		DescriptionProduit
	 */
	public DescriptionProduit getDescriptionProduit()
	{
		return this.ItemH;
	}
	
	/**
	 * Get CatalogueLettre
	 * @return		CatalogueLettre
	 */
	public CatalogueLettre getCatalogueLettre()
	{
		return this.EmailH;
	}
	
	/**
	 * Get Location
	 * @return		Location
	 */
	public Location getLocation()
	{
		return this.RentalH;
	}
	
	/**
	 * Get LigneArticle
	 * @return		LigneArticle
	 */
	public LigneArticle getSerchHandler()
	{
		return this.SearchH;
	}
	
	/**
	 * Save to database
	 * @return	true or false pending success
	 */
	public boolean save() throws ClassNotFoundException
	{
		boolean save = false;
		this.database.addItemList(this.ItemH.getListOfItems());
		this.database.addCustomerList(this.CustomerH.getListOfCustomers());
		this.database.addCustomerWithRentsList(this.RentalH.listRented());
		this.database.setIdItem(this.ItemH.getId());
		this.database.setIdCustomer(this.CustomerH.getId());
		try
		{
			ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream("database.dat"));
			
			out.writeObject(this.database);
				
			out.close();
			save = true;
		}
		catch (IOException e)
		{
			e.printStackTrace();
		}
		
		return save;
	}
	
	/**
	 * Load result
	 */
	public void loadResult()
	{	
		try
		{
			File checkFile = new File("database.dat");
			
			
			if(checkFile.exists())
			{
				ObjectInputStream in = new ObjectInputStream(new FileInputStream(checkFile));
				
				Object obj = in.readObject();
				
				this.database = (Catalogue) obj;
				this.CustomerH.LoadedFromDb(this.database.getCustomerList());			
				this.ItemH.LoadedFromDb(this.database.getItemList());
				this.RentalH.LoadedFromDb(this.database.getCustomerWithRentsList());
				this.ItemH.setId(this.database.getIdItem());
				this.CustomerH.setId(this.database.getIdCustomer());
				in.close();
			}
			
		}
		catch (ClassNotFoundException | IOException e)
		{
			e.printStackTrace();
		}
	}
	
	public static void main(String[] args)
	{
		InterfaceConnexion Login = new InterfaceConnexion();
		Login.setTitle("Club Video");
		Login.getContentPane().setForeground(Color.BLACK);
		Login.getContentPane().setBackground(new Color(244, 164, 96));
		Login.getContentPane().setLayout(new BorderLayout(1, 1));
	}
}
